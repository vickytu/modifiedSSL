/**
 * <p>Title: CPSC 433/533 Programming Assignment</p>
 *
 * <p>Description: SSL implementation</p>
 *
 * <p>Copyright: Copyright (c) 2016</p>
 *
 * <p>Company: Yale University</p>
 *
 * @author Shona Seema Hemmady, Amelia Grace Holcomb, Vicky Tu
 * @version 1.0
 */
import java.util.*;
import java.nio.ByteBuffer;
import java.lang.Math;
import java.io.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import java.util.Base64.*;
import java.nio.charset.StandardCharsets;


public class SSLlib{

    /* fields to be implemented by student */


    enum SSLState {
        // protocol states, all of these are after the action has been done, so HELO = HELO_SENT
        NEW,
        HELO,
        CERT, // client-only
        S_DONE, // client-only
        C_KEYX, // server-only
        FINISHED,
        DONE,
        SHUTDOWN 
    }

    public SSLlib(TCPSock sock, TCPManager tcpMan) {
        /* to be implemented by student */
    }

    public boolean isNew() {
        return (sslState == SSLState.NEW);
    }
    public boolean isHelo() {
        return (sslState == SSLState.HELO);
    }
    public boolean isCert() {
        return (sslState == SSLState.CERT);
    }
    public boolean isS_Done() {
        return (sslState == SSLState.S_DONE);
    }
    public boolean isC_Keyx() {
        return (sslState == SSLState.C_KEYX);
    }
    public boolean isFinished() {
        return (sslState == SSLState.FINISHED);
    }
    public boolean isDone() {
        return (sslState == SSLState.DONE);
    }
    
    public void setNew() {
        sslState = SSLState.NEW;
    }
    public void setHelo() {
        sock.state = TCPSock.State.HANDSHAKE;
        sslState = SSLState.HELO;
    }
    public void setCert() {
        sslState = SSLState.CERT;
    }
    public void setS_Done() {
        sslState = SSLState.S_DONE;
    }
    public void setC_Keyx() {
        sslState = SSLState.C_KEYX;
    }
    public void setFinished() {
        sslState = SSLState.FINISHED;
    }
    public void setDone() {
        sslState = SSLState.DONE;
    }

//////////      INITIALIZATIONS            //////////////

    // initialization for clients only
    public void ssl_client_init() {
        /* to be implemented by student */
    }

    //initialization for servers only
    public void ssl_server_init() {
    /* to be implemented by student */
    }

//////////      MAJOR FUNCTIONS         //////////////


    // server side: accept an SSL connection on top of current TCP connection
    // returns < 1 on fatal SSL error
    // returns 1 on success
    // returns > 1 if handshake is still incomplete 
    public int ssl_accept(){
        // SERVER STATES ARE FOR THOSE MESSAGES IT HAS RECEIVED !!!!!!!!
        if(die) {
            return -1;
        }

        if(sock.state == TCPSock.State.ESTABLISHED) {
            //System.out.println("socket established, returning 1");
            return 1;
        }

        if (sock.state == TCPSock.State.PREESTABLISHED) {
            System.out.println("Server state == ESTABLISHED");
            return 2;
        }

        else if (sslState == SSLState.NEW) {
            // send HELO, CERT, and S_DONE, then change state
            System.out.println("Server sending HELO, CERT, and S_DONE");
            sendHelo();
            sendCert();
            sendS_done();
            sslState = SSLState.HELO;
            return 2;

        }
        else if (sslState == SSLState.HELO) {
            return 2;

        }
        else if (sslState == SSLState.C_KEYX) {
            // tcpman already called a method in here to deal with c_keyx
            return 2;

        }
        else if (sslState == SSLState.FINISHED) {
            // send FINISHED
            sslState = SSLState.DONE;
            sock.state = TCPSock.State.ESTABLISHED;
            return 1;

        }
        else {
            //error
            System.out.println("accept error");
        }
    
        return 0;
    }

    // client side: initiate an SSL connection on top of current TCP connection
    // returns < 1 on fatal SSL error
    // returns 1 on success
    // returns > 1 if handshake is still incomplete    
    public int ssl_connect(){
        // CLIENT STATES ARE FOR THOSE MESSAGES IT IS EXPECTING !!!!!!!!

        //System.out.println("ssl_connect has been called");

        if(die) {
            return -1;
        }

        if(sock.state == TCPSock.State.ESTABLISHED) {
            //System.out.println("socket established, returning 1");
            return 1;
        }
        if(sock.state == TCPSock.State.PREESTABLISHED) {
            sock.state = TCPSock.State.HANDSHAKE;
            System.out.println("Client sock state == HANDSHAKE");
            sendHelo();
            sslState = SSLState.HELO;
            return 2;

        } 
        else if (sslState == SSLState.HELO) {
            System.out.println("Client state == HELO");
            return 2;
        }
        else if (sslState == SSLState.CERT) {
            // tcpman called something to deal with helo
            System.out.println("Client state == CERT");
            return 2;
        }
        else if (sslState == SSLState.S_DONE) {
            // tcpman called something to deal with cert
            System.out.println("Client state == S_DONE");
            return 2;

        }
        else if (sslState == SSLState.FINISHED) {
            // tcpman called stuff to send C_KEYX and FINISHED
            System.out.println("Client state == FINISHED");
            return 2;
        }
        else if (sslState == SSLState.DONE) {
            System.out.println("Client state == DONE");
            sock.state = TCPSock.State.ESTABLISHED;
            return 1;
            
        }
        else {
            //error
            System.out.println("connect error");
        }


        return 0;
    }

    // FUNCTIONS TO MAKE

    // decrypt ciphertext using the symmetric key
    public byte[] ssl_decrypt(byte[] cipherText){
        /* to be implemented by student */
        return null;
    }

    // encrypt plaintext using the symmetric key
    public byte[] ssl_encrypt(byte[] plainText){
        /* to be implemented by student */
        return null;
    }

    /*Signature: int ssl_shutdown(SSL *ssl)
            Return: 0 shutdown not yet finished, call shutdown again if want a bidirectional shutdown
            1 shutdown successfully completed
            -1 shutdown unsuccessful due to fatal error*/
    public int ssl_shutdown(){
        /* to be implemented by student */
        return 0;
    }

//////////      HELPER FUNCTIONS        //////////////

    // write a HELO transport and send it out
    public void sendHelo(){
        /* to be implemented by student */
    }

    // parse through a received HELO transport, saving relevant fields
    public void parseHelo(byte[] pay){
        /* to be implemented by student */
    }

    // write and sign a certificate into a CERT transport and send it out
    public void sendCert() {
        /* to be implemented by student */
    }


    // parse through a received certificate, checking valid signature and correct domain name
    // save the enclosed public key
    public boolean parseCert(byte[] payload) {
        /* to be implemented by student */
        return true;

    }

    // send an S_DONE transport
    public void sendS_done() {
        /* to be implemented by student */
    }
	
	// generate a symmetric key as specified in RFC2246, p11-12
    // send key in C_KEYX transport
	public int sendKey() {
        /* to be implemented by student */
		return 1;
	}
	
    // parse through a received C_KEYX transport, saving key
	public int parseKey(byte[] pay) {
        /* to be implemented by student */
		return 1;
	}
	
	// generate symmetric key from Pre-Master Secret, rand_c, rand_s
	// split Pre-Master Secret into half, use one half with HMAC-SHA1 and other half
	// with HMAC-MD5 in combination with rand_c and rand_s
	public void genSymKey() {
        /* to be implemented by student */	
	}
	
	
    // If I am a client, I send the server a digest of the msgs I have sent (rand_c)
    // send a digest of the handshake transaction in a FINISHED transport
    public void sendFinished() {
        /* to be implemented by student */
    }

    // If I am a server, I check by hashing the msg I've received (rand_c)
    // parse through a received digest, verifying that it matches the local version of the transaction
    public int parseFinished(byte[] payload) {
        /* to be implemented by student */
        return -1;
    }

        // make packet times which are then sent 
    public int sslSendPacket(int type, byte[] payload) {
        
        int count = 0; // index of first byte to be written
        int len = payload.length;
        while (count < len) {

            int toWrite = Math.min((len - count), Transport.MAX_PAYLOAD_SIZE);
            byte[] bufWrite = Arrays.copyOfRange(payload, count, count + toWrite);
            Transport t;
            try {
                t = new Transport(sock.localPort, sock.destPort, type, 
                    sock.windowSize, sock.seqNum, bufWrite);
                
            } catch (Exception e) {
                System.out.println("Error caught: ");
                e.printStackTrace();
                return -1; // error
            }
            
            if (t != null) {
                PacketTime pt = new PacketTime(t, tcpMan.getMan().now());
                count += toWrite;
                tcpMan.sslSendPkt(sock.destAddr, pt, sock, sock.seqNum);
            }
        }
        return 1; // success
    }

}